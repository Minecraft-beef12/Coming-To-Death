# Coming To Death — Android wrapper

This project packages the supplied `Coming To Death.html` game in a fullscreen Android WebView. The original HTML is stored at `app/src/main/assets/index.html`. The game uses Three.js and Google Fonts from online CDNs, so internet access is required for those resources to load.

## Build an APK

### Easiest: GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open **Actions** → **Build Android APK** → **Run workflow** (or push to `main`).
3. Download the `Coming-To-Death-APK` artifact from the completed run. Inside is `app-debug.apk`.

### Android Studio
Open this folder as a project, allow Gradle sync, then run **Build → Build APK(s)**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

This is a debug APK, not a Play Store release-signed APK.
